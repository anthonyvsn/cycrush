#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"


int image1(){
    FILE *fichier = fopen("logo.txt", "r");
    int caractere;

    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 1;
    }

    while ((caractere = fgetc(fichier)) != EOF) {
        printf("%c", caractere);
    }

    fclose(fichier);

    return 0;
}


int image2(){
    FILE *fichier = fopen("graph1.txt", "r");
    int caractere;

    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier.\n");
        return 1;
    }

    while ((caractere = fgetc(fichier)) != EOF) {
        printf("%c", caractere);
    }

    fclose(fichier);

    return 0;
}

void afiche(int M, int N, int pla[][N]) {
  //logo();
 printf("\033[H\033[J"); // PERMET DE FAIRE UN SEUL TABLEAU 

  printf("  ");
  for (int i = 1; i <= N; i++) {
    if(i<10){
    printf(" %d ", i);
    }
    else{
    printf(" %d", i);
    }
  }
  printf(" ");
 
  printf("\n   ");
  for (int i = 1; i <= N; i++) {
    printf("-- ");
  }
  printf("\n");
  for (int i = 0; i < M; i++) {
    printf("%c |", 65 + i);
    for (int j = 0; j < N; j++) {
      switch(pla[i][j]){
       
        case 6:
          printf("\U0001F36D ");
          break;
        case 1:
          printf("\U0001F36B ");
          break;
        case 2:
          printf("\U0001F36C ");
          break;
        case 3:
          printf("\U0001F36E ");
          break;
        case 4:
          printf("\U0001F36F ");
          break;
        case 5:
          printf("\U0001F9C1 ");
          break;
        default:
          printf("  ");
        }
    }
    printf("\n");
  }
}

int  menu(int *po ){
    int choix; 
    int ple[3][3];
	for (int i =0;i<3;i++){
	   for (int j =0;j<3;j++){
	ple[i][j]=i;
	}
		}
	
    FILE * fic;
    int verif;
     printf("\n");
   printf("Bienvenue dans le jeu\n");
   printf("selectionner votre choix\n");
    do {printf("                        1: jouer\n");
        printf("                        2: option\n");
        printf("                        3: score\n");
        printf("                        4: sauvegarde\n");
        printf("                        5: sortie\n");
    
  verif=scanf("%d",&choix);
  vide_buffer();
  }while(verif!=1);
    
  switch( choix) {
    case 1: printf(" A vous de jouer \n");
    jouer(po);
    break;
  
  
  case 2 : 
	printf("votre objectif est d'avor le plus de point possible.\n'");
	printf("option : choisir le temps :\n");
    printf("                        1 : 2 min \n");
      printf("                        2 : 5 min \n");
    printf("                        3: 10 min \n");
    printf("                        4 : temps illimité \n");
        scanf("%d", &*po);
          switch(*po){
            case 1 : printf("vous avez 2 min \n");
            break;
            case 2 : printf("vous avez 5 min \n");
            break;
            case 3 : printf("vous avez 10 min\n");
            break;
		        case 4 : printf("vous avez le temps illimite\n");
            break;
            
          }
          menu(po);
          return 0;
      
    case 3 : recup_score(po);
          menu(po);
          break;
    case 4:lire_sauvegarde();
    break;
    case 5 :  
      
      image2();
    return 1;
  }
   
    
  return 0;
}
    