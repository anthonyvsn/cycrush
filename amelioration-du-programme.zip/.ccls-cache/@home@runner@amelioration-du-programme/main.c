#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"

                                                              
int main(void) {
  int option=1;
  int *po=&option;
  image1();
  menu(po );
  
  return 0;
}
