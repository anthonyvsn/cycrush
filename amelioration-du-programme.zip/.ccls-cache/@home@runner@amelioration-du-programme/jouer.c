#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"



int jouer( int *po){
int score = 0;
int * pscore= &score;
int temp=0;
int M = 0;
  int N = 0;
  int nbr_sym = 0;
  int *pM = &M;
  int *pN = &N;
  int *pSym = &nbr_sym;
  time_t deb;
  time_t fin;
  int min;
  if(*po==1){
      min=2;
  }
  else if(*po==2){
      min=5;
  }
  else {
    min =10;
  }
  
  demande_utilisateur(pM, pN, pSym);
  srand(time(NULL));
  int pla[M][N];
  int horizontal[M][N];
  int vertical[M][N];
  char c ='a';
  crer_plat(M, N, nbr_sym, pla);
  reaction_en_chaine(M, N, nbr_sym, pla,pscore);
  afiche(M, N, pla);
  deb = time(NULL);
  fin =time(NULL);
  temp = fin-deb;
  *pscore = 0;
  while(victoire(N,M,nbr_sym,pla)==1  &&  temp<10){
    
      demande_case(N,M,nbr_sym,pla,pscore);
      afiche(M, N, pla);
      fin = time(NULL);
    if(*po!=4){
      temp = fin-deb;
    }
    else{
      printf("\n votre score est de : %d \n",*pscore);
      printf("souhaitez vous sauvgarder la partie ? O/N\n");
      scanf("%c",&c);
      if(c=='O'|| c=='o'){
          sauvegarde(N,  M,nbr_sym, *pscore, pla);
          printf("votre partie a été sauvegarder");
          return 1;
      }
      
    }
    
    }
  printf("\nvous avez perdu ");
  printf("\nvotre score est de : %d",*pscore);
	//recup_score(po,pscore);
  
  
  return 0;
}