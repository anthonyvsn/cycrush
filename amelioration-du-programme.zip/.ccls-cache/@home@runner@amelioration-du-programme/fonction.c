#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"










int sauvegarde(int N,int M,int sym, int pscore,int pla[][N]){
	FILE * f = fopen("s.txt","w+");	
	if (f==NULL){
    		printf("impossible d'ouvrir le fichier");
   	 	return 1;
  	}
	else{
		fprintf(f,"%d\n%d\n%d\n%d\n",pscore,M,N,sym);
		for (int i =0;i<M;i++){
		   	for (int j =0;j<N;j++){
				fprintf(f,"%d ",pla[i][j]);
		}
	  	}
	fclose(f);
	}
	return 0;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////::
void vide_buffer(){
while(getchar()!='\n'){}
}

void demande_utilisateur(int *pM, int *pN, int *pSym) {
  int verif;
 do{ printf(" rentrer le nombre de ligne :\n ");
  verif=scanf("%d",&*pM);
  vide_buffer();
  }while(verif!=1);
  do{ printf("rentrer le nombre de colonne :\n ");
  verif=scanf("%d", &*pN);
  vide_buffer();
  }while(verif!=1);
  do{while (*pSym >= 7 || *pSym <= 3) {
    printf(" rentrer le nombre de symbole :\n");
    scanf("%d", *&pSym);
    vide_buffer();
  }
  }while(verif!=1);
}

// crer le plateau de jeu de colone M et de ligne N avec nbr_Sym le nombre de
// symbolle different
void crer_plat(int M, int N, int nbr_Sym, int pla[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      pla[i][j] = rand() % nbr_Sym + 1;
    }
  }
}

// complexité ?
// revoir les espace
// fonction qui permet d'afficher les colonnes et les lignes du tableau

// verifier que qd y'a trois symboles ou plus a cote on les supprimes
void Vertical(int M, int N, int pla[][N], int Vertical[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      if (pla[i][j] != 0) {
        if (i < M - 1) {
          int y = i + 1;
          int compte = 0;
          while (y != M && (pla[i][j] == pla[y][j])) {
            compte++;
            y++;
          }
          if (compte >= 2) {
            for (int k = i; k < y; k++) {
              Vertical[k][j] = 0;
            }
          }
        }
      }
    }
  }
}
// verifier que qd y'a trois symboles ou plus a cote on les supprimes
void Horizontal(int M, int N, int pla[][N], int Horizontal[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      if (pla[i][j] != 0) {
        if (j < N - 1) {
          int y = j + 1;
          int compte = 0;
          while (y != N && (pla[i][j] == pla[i][y])) {
            compte++;
            y++;
          }
          if (compte >= 2) {
            for (int k = j; k < y; k++) {
              Horizontal[i][k] = 0;
            }
          }    
        }
      }
    }
  }
}
void Circulaire_G(int M, int N, int pla[][N], int C[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
       int compte = 0 ;
if (pla[i][0] == pla[i][1]) {
             compte++;
            }
     if (j==0 && compte >=1 && pla[i][N-1]==pla[i][0]){
      C[i][0]= 0;
      C[i][1] = 0;
      C[i][N-1]= 0;
     }
   
    }
  }
 }
 
 void Circulaire_D(int M, int N, int pla[][N], int C[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      int compte = 0 ;
      if (pla[i][N-2] == pla[i][N-1]) {
        compte++;
            }
     if (j==M-2 && compte >=1 && pla[i][N-1]==pla[i][0]){
      C[i][0]= 0;
      C[i][N-2] = 0;
      C[i][N-1]= 0;
     }
    }
  }
 }
// permet de regrouper les deux tableau horizantal et vertical a voir probleme
void simplification(int M, int N, int Horizontale[][N], int Vertical[][N],int C_G[][N],int C_D[][N],int pla[][N]) {
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      if (Horizontale[i][j] == 0 || Vertical[i][j] == 0 || C_G[i][j] == 0 || C_D[i][j] == 0) {
        pla[i][j] = 0;
      }
    }
  }
}
void initialisation(int N,int M, int pla[][N],int horizontale[][N]){
 
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      horizontale[i][j] = pla[i][j];
    }
  }
}
void gravite(int M, int N, int pla[][N]){
  for (int i = M-1;i>=0;i--){
      for (int j = N-1; j >= 0; j--) {
       if (pla[i][j]==0){
        int k = j;
        while (k>=0 && pla[i][k]==0){
          k--;
        }
         if(k>=0){
           pla[i][j]= pla[i][k];
           pla[i][k]=0;
         }
       }
      }
    }
}

void ajout(int M, int N, int nbr_Sym, int pla[][N]){
  for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      if (pla[i][j]==0){
        pla[i][j] = rand() % nbr_Sym + 1;
      }
    }
  }
}

 int compte_zero(int M, int N, int pla[][N]){
   int zero = 0;
   for (int i = 0; i < M; i++) {
    for (int j = 0; j < N; j++) {
      if (pla[i][j]==0){
        zero++;
      }
      else{
        break;
      }
    }
   }
   return zero;  
 }

void  verification(int M, int N,int nbr_Sym, int pla[][N]){
    int horizontal[M][N];
    int vertical[M][N];
    int C_G[M][N];
    int C_D[M][N];
    ajout(M, N, nbr_Sym,pla );
    initialisation(N,M, pla, horizontal);
  initialisation(N,M, pla, vertical);
  initialisation(N,M, pla, C_G);
  initialisation(N,M, pla, C_D);
    Horizontal(M, N, pla, horizontal);
    Vertical(M, N, pla, vertical);
    Circulaire_G(M,N,pla,C_G);
    Circulaire_D(M,N,pla,C_D);
    simplification(M, N, horizontal, vertical,C_G,C_D ,pla);
    gravite(M,N,pla);

}

void reaction_en_chaine(int M, int N,int nbr_Sym, int pla[][N],int * pscore){
  int zero1;
  *pscore +=compte_zero(M, N, pla);
  do {
    verification(M, N, nbr_Sym , pla);
    printf("\n");
    afiche( M, N, pla);
    zero1 = compte_zero(M, N, pla);
    *pscore +=compte_zero(M, N, pla);
    }while (zero1 !=0);
   printf("\nvotre score est de : %d",*pscore);
}

int echange(int N,int M,int nbr_sym,int colone1, int colone2,int ligne1,int ligne2,int verif, int pla[][N],int * pscore){
  int pla_temp[M][N];
  initialisation(N,M, pla, pla_temp);
  int temp = pla_temp[ligne2][colone2-1];
  pla_temp[ligne2][colone2-1] = pla_temp[ligne1][colone1-1];
  pla_temp[ligne1][colone1-1] = temp;
  verification(M, N, nbr_sym, pla_temp);
  if(compte_zero(M,N, pla_temp)!=0){
      if(verif == 0){
        return 1;
      }
    else{
      initialisation(N,M, pla_temp, pla);
      reaction_en_chaine(M, N,nbr_sym, pla,pscore);
    }
  }
  else{
    return 0;
  }
}

int victoire(int N,int M,int nbr_sym, int pla[][N]){
  for (int i =0;i<M;i++){
   for (int j =0;j<N;j++){
     int k = 0;
     while(k<M){
       for (int l =0;l<N;l++){
         if(echange(N,M,nbr_sym,j+1,l+1,i,k,0,pla,0)==1){
           return  1;
         }
       }
      k++;
     }
    }
  }
  return 0;
}

void demande_case (int N,int M,int nbr_sym, int pla[][N],int * pscore){
  char lettre1;
  int colone1;    
  int ligne1;
  char lettre2;
  int colone2;
  int ligne2;
  int verif;
  do {
  printf("rentrer une lettre  : \n");
  verif=scanf("%c",&lettre1);
  vide_buffer();
  if (lettre1>=97){
    lettre1 = lettre1 - 32;
  }
  }while(lettre1<65 || lettre1>65+M );
    
  do{
  printf("rentrer un chiffre   : ");
  verif = scanf("%d",&colone1);
  vide_buffer();
  }while(verif !=1 || colone1<=0 || colone1>N);
  ligne1 = lettre1-65;
  do{
  printf("rentrer une deuxieme lettre  : ");
  scanf("%c",&lettre2);
   if (lettre2>=97){
    lettre2 = lettre2 - 32;
  }
  vide_buffer();
   }while(lettre2<65 || lettre2>65+M );
  do {
  printf("colone un deuxime chiffre: ");
  scanf("%d",&colone2);
  vide_buffer();
  }while(verif !=1 || colone2<=0 || colone2>N);
  ligne2 = lettre2-65;  
  echange(N,M,nbr_sym, colone1, colone2,ligne1,ligne2,1,pla,pscore);
}


////////////////////////////

                      
                                                              

