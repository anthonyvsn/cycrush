#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"

int lire_sauvegarde(){
 int score;
  int *pscore;
int N;
  int M;
  int sym;
  char c;
  int temp;
  	FILE * f = fopen("s.txt","r");	
	if (f==NULL){
    		printf("impossible d'ouvrir le fichier");
   	 	return 1;
  	}
	else{
    fscanf(f, "%d", &score);
    fscanf(f, "%c", &c);
    fscanf(f, "%d", &M);
    fscanf(f, "%c", &c);
    fscanf(f, "%d", &N);
    fscanf(f, "%c", &c);
    fscanf(f, "%d", &sym);
    int pla[M][N];
    for(int i =0 ; i<M;i++){
      for (int j =0;j<N;j++){
      fscanf(f,"%d",&pla[i][j]);
        fscanf(f, "%c", &c);
      } 
    }
     fclose(f);
    afiche(M, N, pla);
    //reaction_en_chaine(M,N,sym,pla,pscore);
    }
	return 0;
}