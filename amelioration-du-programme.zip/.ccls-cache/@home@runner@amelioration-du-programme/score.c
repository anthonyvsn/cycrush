#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include "fonction.h"




int recup_score(int *po ){
  char c[30];
  int temp;
  int temp2;
  int max = 0;
  int len;
  FILE *f =fopen("score.txt","r");
  if (f==NULL){
    printf("impossible d'ouvrir le fichier");
    return 1;
  }
  else {
    while(fgets(c,sizeof c,f)!=NULL){
      temp = c[0] -'0';
      printf("%s",c);
      temp2 =0;
      len =strlen(c);
      if ((*po)==temp){
        for (int i=1; i<len-1;i++){
          temp = c[i]-'0';
          temp2 = temp2 + temp*pow(10,len-2-i) ;
        } 

        }
      if (temp2>max){
          max = temp2;
      }
    }
    printf("\033[H\033[J");
    printf("le meilleur score dans ce mode de jeu est de : %d points \n",max);
    fclose(f);
  }
  return 0;
}